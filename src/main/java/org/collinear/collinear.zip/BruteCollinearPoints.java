import java.util.ArrayList;
import java.util.Arrays;

public class BruteCollinearPoints {
    private final LineSegment[] segments;

    public BruteCollinearPoints(Point[] points) {
        if (points == null) {
            throw new IllegalArgumentException();
        }
        Point[] pointsCopy = new Point[points.length];
        for(int i = 0; i < points.length; i++){
            pointsCopy[i] = points[i];
        }
        checkNoDuplicates(pointsCopy);
        this.segments = calculateSegments(pointsCopy);
    }

    private void checkNoDuplicates(Point[] array) {
        for (int i = 0; i < array.length; i++) {
            for (int j = i + 1; j < array.length; j++) {
                Point A = array[i];
                Point B = array[j];
                if (A == null || B == null) {
                    throw new IllegalArgumentException();
                }
                if (A.compareTo(B) == 0) {
                    throw new IllegalArgumentException();
                }
            }
        }
    }

    private LineSegment compareFourPoints(int i, int j, int k, int l, Point[] points) {
        Point A = points[i];
        Point B = points[j];
        Point C = points[k];
        Point D = points[l];
        double slopeAtoB = A.slopeTo(B);
        double slopeAtoC = A.slopeTo(C);
        double slopeAtoD = A.slopeTo(D);
        if (slopeAtoB == slopeAtoC && slopeAtoC == slopeAtoD) {
            Point origin = new Point(0, 0);
            Point[] collinearPoints = {A, B, C, D};
            Arrays.sort(collinearPoints, origin.slopeOrder());
            return new LineSegment(collinearPoints[0], collinearPoints[3]);
        }
        return null;
    }

    public LineSegment[] segments() {
        return this.segments;
    }

    private LineSegment[] calculateSegments(Point[] points) {
        ArrayList<LineSegment> result = new ArrayList<>();
        for (int i = 0; i < points.length - 3; i++) {
            for (int j = i + 1; j < points.length - 2; j++) {
                for (int k = j + 1; k < points.length - 1; k++) {
                    for (int l = k + 1; l < points.length; l++) {
                        LineSegment line = compareFourPoints(i, j, k, l, points);
                        if (line != null) result.add(line);
                    }
                }
            }
        }
        return result.toArray(new LineSegment[0]);
    }

    public int numberOfSegments() {
        return segments().length;
    }
}
